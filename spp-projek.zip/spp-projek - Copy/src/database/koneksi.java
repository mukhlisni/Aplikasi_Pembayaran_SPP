package database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class koneksi {
    private static Connection conn;

    public static Connection getKoneksi() {
        if (conn == null) {
            try {
                String url = "jdbc:mysql://localhost:3306/spp_db";
                String user = "root"; // ganti jika user MySQL kamu berbeda
                String password = ""; // ganti jika password MySQL kamu ada

                Class.forName("com.mysql.cj.jdbc.Driver");
                conn = DriverManager.getConnection(url, user, password);
                System.out.println("Koneksi ke database berhasil.");
            } catch (ClassNotFoundException | SQLException e) {
                System.out.println("Koneksi ke database gagal: " + e.getMessage());
            }
        }
        return conn;
    }
}