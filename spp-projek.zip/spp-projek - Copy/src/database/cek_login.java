package database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class cek_login {
    public static String[] login(String username, String password) {
        String[] result = new String[2]; // [0] = id_user, [1] = role

        try {
            Connection conn = koneksi.getKoneksi();
            String sql = "SELECT * FROM user WHERE username=? AND password=?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, username);
            stmt.setString(2, password);

            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                result[0] = rs.getString("id_user");
                result[1] = rs.getString("role");
            }

            rs.close();
            stmt.close();
        } catch (Exception e) {
            System.out.println("Login error: " + e.getMessage());
        }

        return result;
    }
}
