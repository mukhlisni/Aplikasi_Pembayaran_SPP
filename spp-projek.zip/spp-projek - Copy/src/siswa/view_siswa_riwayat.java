package siswa;

import database.koneksi;
import java.awt.event.*;
import java.sql.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import admin.view_login;

public class view_siswa_riwayat extends javax.swing.JFrame {

    private String idUserLogin;
    private DefaultTableModel model;
    
    public view_siswa_riwayat(String idUserLogin) {
        initComponents();
        this.idUserLogin = idUserLogin;
        labelNama.setText("-");
        tomRiwayat.setEnabled(false); // menonaktifkan tombol Riwayat karena sedang di halaman ini
        tampilNama();
        loadRiwayat();
    }

    private view_siswa_riwayat() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    private void tampilNama() {
        try {
            Connection conn = koneksi.getKoneksi();
            String sql = "SELECT nama FROM siswa WHERE id_user = ?";
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.setString(1, idUserLogin);
            ResultSet rs = pst.executeQuery();
            if (rs.next()) {
                labelNama.setText(rs.getString("nama"));
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Gagal menampilkan nama: " + e.getMessage());
        }
    }

    private void loadRiwayat() {
        model = new DefaultTableModel();
        model.addColumn("Id Tagihan");
        model.addColumn("Tahun");
        model.addColumn("Bulan");
        model.addColumn("Nominal");
        model.addColumn("Status");
        model.addColumn("File Path");

        try {
            Connection conn = koneksi.getKoneksi();
            String sql = "SELECT t.id_tagihan, s.tahun, s.bulan, s.nominal, t.status, t.file_path " +
                         "FROM tagihan t JOIN spp s ON t.id_spp = s.id_spp " +
                         "WHERE t.nis = (SELECT nis FROM siswa WHERE id_user = ?) AND t.status = 'LUNAS'";
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.setString(1, idUserLogin);
            ResultSet rs = pst.executeQuery();

            while (rs.next()) {
                model.addRow(new Object[]{
                    rs.getString("id_tagihan"),
                    rs.getInt("tahun"),
                    rs.getString("bulan"),
                    rs.getInt("nominal"),
                    rs.getString("status"),
                    rs.getString("file_path")
                });
            }
            tabelRiwayat.setModel(model);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Gagal menampilkan riwayat tagihan: " + e.getMessage());
        }
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        tomTagihan = new javax.swing.JButton();
        tomRiwayat = new javax.swing.JButton();
        tomLogout = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        labelNama = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabelRiwayat = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(51, 102, 255));

        tomTagihan.setText("Tagihan");
        tomTagihan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tomTagihanActionPerformed(evt);
            }
        });

        tomRiwayat.setText("Riwayat");
        tomRiwayat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tomRiwayatActionPerformed(evt);
            }
        });

        tomLogout.setText("Logout");
        tomLogout.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tomLogoutActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(tomTagihan)
                    .addComponent(tomRiwayat)
                    .addComponent(tomLogout))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(tomTagihan)
                .addGap(18, 18, 18)
                .addComponent(tomRiwayat)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(tomLogout)
                .addContainerGap())
        );

        jLabel1.setFont(new java.awt.Font("Segoe UI", 3, 16)); // NOI18N
        jLabel1.setText("Riwayat Tagihan");

        labelNama.setText("-");

        tabelRiwayat.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "Id Tagihan", "Tahun", "Bulan", "Nominal", "Status", "File Path"
            }
        ));
        jScrollPane1.setViewportView(tabelRiwayat);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(labelNama, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 663, Short.MAX_VALUE))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(labelNama)
                    .addComponent(jLabel1))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 275, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(126, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void tomTagihanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tomTagihanActionPerformed
        new view_siswa_tagihan(idUserLogin).setVisible(true);
        this.dispose();
    }//GEN-LAST:event_tomTagihanActionPerformed

    private void tomRiwayatActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tomRiwayatActionPerformed
        
    }//GEN-LAST:event_tomRiwayatActionPerformed

    private void tomLogoutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tomLogoutActionPerformed
        new view_login().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_tomLogoutActionPerformed

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new view_siswa_riwayat().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel labelNama;
    private javax.swing.JTable tabelRiwayat;
    private javax.swing.JButton tomLogout;
    private javax.swing.JButton tomRiwayat;
    private javax.swing.JButton tomTagihan;
    // End of variables declaration//GEN-END:variables
}
