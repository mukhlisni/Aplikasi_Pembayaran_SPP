package siswa;

import database.koneksi;
import java.awt.event.*;
import java.io.*;
import java.sql.*;
import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.table.DefaultTableModel;
import admin.view_login;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;

public class view_siswa_tagihan extends javax.swing.JFrame {

    private String idUserLogin;
    private DefaultTableModel model;
    
    public view_siswa_tagihan(String idUserLogin) {
        initComponents();
        this.idUserLogin = idUserLogin; // ✅ set nilai yang benar
                        
        labelNama.setText("-");
        tomTagihan.setEnabled(false);
                
        labelIdtagihan.setText("-");
        tomUpload.setEnabled(false);

        tampilNama();
        loadTagihan();

        tabelTagihan.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent evt) {
                int row = tabelTagihan.getSelectedRow();
                if (row != -1) {
                    labelIdtagihan.setText(model.getValueAt(row, 0).toString());
                    tomUpload.setEnabled(true);
                }
            }
        });
    }

    private view_siswa_tagihan() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    private void tampilNama() {
        try {
            Connection conn = koneksi.getKoneksi();
            String sql = "SELECT nama FROM siswa WHERE id_user = ?";
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.setString(1, idUserLogin);
            ResultSet rs = pst.executeQuery();
            if (rs.next()) {
                labelNama.setText(rs.getString("nama"));
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Gagal menampilkan nama: " + e.getMessage());
        }
    }
    
    private void loadTagihan() {
        model = new DefaultTableModel();
        model.addColumn("Id Tagihan");
        model.addColumn("Tahun");
        model.addColumn("Bulan");
        model.addColumn("Nominal");
        model.addColumn("Status");
        model.addColumn("File Path");

        try {
            Connection conn = koneksi.getKoneksi();
            String sql = "SELECT t.id_tagihan, s.tahun, s.bulan, s.nominal, t.status, t.file_path " +
                         "FROM tagihan t JOIN spp s ON t.id_spp = s.id_spp " +
                         "WHERE t.nis = (SELECT nis FROM siswa WHERE id_user = ?) AND t.status = 'Belum'";
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.setString(1, idUserLogin);
            ResultSet rs = pst.executeQuery();

            while (rs.next()) {
                model.addRow(new Object[]{
                    rs.getString("id_tagihan"),
                    rs.getInt("tahun"),
                    rs.getString("bulan"),
                    rs.getInt("nominal"),
                    rs.getString("status"),
                    rs.getString("file_path")
                });
            }
            tabelTagihan.setModel(model);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Gagal menampilkan tagihan: " + e.getMessage());
        }
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        tomTagihan = new javax.swing.JButton();
        tomRiwayat = new javax.swing.JButton();
        tomLogout = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        labelNama = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabelTagihan = new javax.swing.JTable();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        labelIdtagihan = new javax.swing.JLabel();
        tomUpload = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(51, 102, 255));

        tomTagihan.setText("Tagihan");
        tomTagihan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tomTagihanActionPerformed(evt);
            }
        });

        tomRiwayat.setText("Riwayat");
        tomRiwayat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tomRiwayatActionPerformed(evt);
            }
        });

        tomLogout.setText("Logout");
        tomLogout.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tomLogoutActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(tomTagihan)
                    .addComponent(tomRiwayat)
                    .addComponent(tomLogout))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(tomTagihan)
                .addGap(18, 18, 18)
                .addComponent(tomRiwayat)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(tomLogout)
                .addContainerGap())
        );

        jLabel1.setFont(new java.awt.Font("Segoe UI", 3, 16)); // NOI18N
        jLabel1.setText("Tagihan");

        labelNama.setText("-");

        tabelTagihan.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "Id Tagihan", "Tahun", "Bulan", "Nominal", "Status", "File Path"
            }
        ));
        jScrollPane1.setViewportView(tabelTagihan);

        jLabel3.setText("Id Tagihan");

        jLabel4.setText("Bukti Bayar");

        labelIdtagihan.setText("-");

        tomUpload.setText("Upload");
        tomUpload.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tomUploadActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(labelNama, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 663, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(jLabel4, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 68, Short.MAX_VALUE)
                            .addComponent(jLabel3, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(tomUpload)
                            .addComponent(labelIdtagihan, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(labelNama)
                    .addComponent(jLabel1))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 275, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(labelIdtagihan))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(tomUpload))
                .addContainerGap(63, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void tomUploadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tomUploadActionPerformed
        // TODO add your handling code here:
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Pilih Bukti Pembayaran");
        fileChooser.setFileFilter(new FileNameExtensionFilter("Gambar dan PDF", "jpg", "png", "pdf"));

        int result = fileChooser.showOpenDialog(this);
        if (result == JFileChooser.APPROVE_OPTION) {
            File file = fileChooser.getSelectedFile();
            String destFolder = "uploads/";
            File destFile = new File(destFolder + file.getName());

            try {
                Files.copy(file.toPath(), destFile.toPath(), java.nio.file.StandardCopyOption.REPLACE_EXISTING);

                // Update database
                Connection conn = koneksi.getKoneksi();
                String sql = "UPDATE tagihan SET file_path = ? WHERE id_tagihan = ?";
                PreparedStatement pst = conn.prepareStatement(sql);
                pst.setString(1, destFile.getPath());
                pst.setString(2, labelIdtagihan.getText());
                pst.executeUpdate();

                JOptionPane.showMessageDialog(this, "Bukti pembayaran berhasil diupload.");
                labelIdtagihan.setText("");
                tomUpload.setEnabled(false);
                loadTagihan();
            } catch (IOException | SQLException e) {
                JOptionPane.showMessageDialog(this, "Gagal upload file: " + e.getMessage());
            }
        }
    }//GEN-LAST:event_tomUploadActionPerformed

    private void tomTagihanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tomTagihanActionPerformed

    }//GEN-LAST:event_tomTagihanActionPerformed

    private void tomRiwayatActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tomRiwayatActionPerformed
        new view_siswa_riwayat(idUserLogin).setVisible(true);
        this.dispose();
    }//GEN-LAST:event_tomRiwayatActionPerformed

    private void tomLogoutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tomLogoutActionPerformed
        new view_login().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_tomLogoutActionPerformed

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new view_siswa_tagihan().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel labelIdtagihan;
    private javax.swing.JLabel labelNama;
    private javax.swing.JTable tabelTagihan;
    private javax.swing.JButton tomLogout;
    private javax.swing.JButton tomRiwayat;
    private javax.swing.JButton tomTagihan;
    private javax.swing.JButton tomUpload;
    // End of variables declaration//GEN-END:variables
}
