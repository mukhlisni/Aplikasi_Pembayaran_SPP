package admin;

import java.sql.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import database.koneksi;

public class view_data_spp extends javax.swing.JFrame {
    
    DefaultTableModel model;
    DefaultTableModel modelTagihan;
    private boolean modeEdit = false;

    public view_data_spp() {
        initComponents();
        
        tabelTagihan.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tabelTagihanMouseClicked(evt); // jalankan fungsi saat baris diklik
            }
        });
        
        tomSpp.setEnabled(false); // dinonaktifkan karena sudah di halaman ini
        loadTable();
        loadTabelTagihan();
        setButtonStateAwal();
        addTextFieldListeners();
        teksIdspp.setEditable(true);
        tomLunas.setEnabled(false);      // tombol Lunas awalnya nonaktif
        labelIdtagihan.setText(""); 
    }
    
    private void loadTable() {
        model = new DefaultTableModel();
        model.addColumn("Id SPP");
        model.addColumn("Tahun");
        model.addColumn("Bulan");
        model.addColumn("Nominal");

        try {
            String sql = "SELECT * FROM spp";
            Connection conn = koneksi.getKoneksi();
            Statement stmt = conn.createStatement();
            ResultSet res = stmt.executeQuery(sql);

            while (res.next()) {
                model.addRow(new Object[]{
                    res.getString("id_spp"),
                    res.getString("tahun"),
                    res.getString("bulan"),
                    res.getString("nominal"),
                });
            }

            tabelSpp.setModel(model);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Gagal memuat data: " + e.getMessage());
        }
    }

    private void addTextFieldListeners() {
        java.awt.event.KeyAdapter listener = new java.awt.event.KeyAdapter() {
            @Override
            public void keyReleased(java.awt.event.KeyEvent evt) {
                if (!modeEdit) {
                    setButtonStateFormAktif();
                }
            }
        };

        teksIdspp.addKeyListener(listener);
        teksTahun.addKeyListener(listener);
        teksBulan.addKeyListener(listener);
        teksNominal.addKeyListener(listener);
    }

    private void setButtonStateAwal() {
        tomTambah.setEnabled(false);
        tomUpdate.setEnabled(false);
        tomDelete.setEnabled(false);
        tomBatal.setEnabled(false);
    }

    private void setButtonStateFormAktif() {
        tomTambah.setEnabled(true);
        tomUpdate.setEnabled(false);
        tomDelete.setEnabled(false);
        tomBatal.setEnabled(true);
    }

    private void setButtonStateTabelKlik() {
        tomTambah.setEnabled(false);
        tomUpdate.setEnabled(true);
        tomDelete.setEnabled(true);
        tomBatal.setEnabled(true);
    }

    private void clearForm() {
        teksIdspp.setText("");
        teksTahun.setText("");
        teksBulan.setText("");
        teksNominal.setText("");
        teksIdspp.setEditable(true);
        setButtonStateAwal();
        modeEdit = false;
    }
    
    private void loadTabelTagihan() {
        modelTagihan = new DefaultTableModel();
        modelTagihan.addColumn("Id Tagihan");
        modelTagihan.addColumn("NIS");
        modelTagihan.addColumn("Nama");
        modelTagihan.addColumn("Id SPP");
        modelTagihan.addColumn("Status");
        modelTagihan.addColumn("File Path");

        try {
            Connection conn = koneksi.getKoneksi();
            Statement stmt = conn.createStatement();

            String sql = """
                SELECT t.id_tagihan, s.nis, s.nama, t.id_spp, t.status, t.file_path
                FROM tagihan t
                JOIN siswa s ON t.nis = s.nis
                """;

            ResultSet rs = stmt.executeQuery(sql);

            while (rs.next()) {
                modelTagihan.addRow(new Object[] {
                    rs.getString("id_tagihan"),
                    rs.getString("nis"),
                    rs.getString("nama"),
                    rs.getString("id_spp"),
                    rs.getString("status"),
                    rs.getString("file_path")
                });
            }

            tabelTagihan.setModel(modelTagihan);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Gagal memuat data tagihan: " + e.getMessage());
        }
    }
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        tomUser = new javax.swing.JButton();
        tomSpp = new javax.swing.JButton();
        tomTagihan = new javax.swing.JButton();
        tomSiswa = new javax.swing.JButton();
        tomKelas = new javax.swing.JButton();
        tomLogout = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        teksTahun = new javax.swing.JTextField();
        teksBulan = new javax.swing.JTextField();
        teksNominal = new javax.swing.JTextField();
        teksIdspp = new javax.swing.JTextField();
        tomTambah = new javax.swing.JButton();
        tomUpdate = new javax.swing.JButton();
        tomDelete = new javax.swing.JButton();
        tomBatal = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabelSpp = new javax.swing.JTable();
        jLabel6 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        tabelTagihan = new javax.swing.JTable();
        jLabel7 = new javax.swing.JLabel();
        labelIdtagihan = new javax.swing.JLabel();
        tomLunas = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel2.setBackground(new java.awt.Color(51, 102, 255));

        tomUser.setText("Data User");
        tomUser.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tomUserActionPerformed(evt);
            }
        });

        tomSpp.setText("Data  SPP");
        tomSpp.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tomSppActionPerformed(evt);
            }
        });

        tomTagihan.setText("Data Tagihan");
        tomTagihan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tomTagihanActionPerformed(evt);
            }
        });

        tomSiswa.setText("Data Siswa");
        tomSiswa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tomSiswaActionPerformed(evt);
            }
        });

        tomKelas.setText("Data Kelas");
        tomKelas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tomKelasActionPerformed(evt);
            }
        });

        tomLogout.setText("Logout");
        tomLogout.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tomLogoutActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(tomUser, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(tomKelas, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(tomSiswa, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(tomSpp, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(tomTagihan, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(tomLogout, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(tomUser)
                    .addComponent(tomSpp)
                    .addComponent(tomTagihan)
                    .addComponent(tomSiswa)
                    .addComponent(tomKelas)
                    .addComponent(tomLogout))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jLabel1.setFont(new java.awt.Font("Segoe UI", 3, 16)); // NOI18N
        jLabel1.setText("Data SPP");

        jLabel2.setText("Id SPP");

        jLabel3.setText("Tahun");

        jLabel4.setText("Bulan");

        jLabel5.setText("Nominal");

        teksIdspp.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                teksIdsppActionPerformed(evt);
            }
        });

        tomTambah.setText("Tambah");
        tomTambah.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tomTambahActionPerformed(evt);
            }
        });

        tomUpdate.setText("Update");
        tomUpdate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tomUpdateActionPerformed(evt);
            }
        });

        tomDelete.setText("Delete");
        tomDelete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tomDeleteActionPerformed(evt);
            }
        });

        tomBatal.setText("Batal");
        tomBatal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tomBatalActionPerformed(evt);
            }
        });

        tabelSpp.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Id SPP", "Tahun", "Bulan", "Nominal"
            }
        ));
        tabelSpp.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tabelSppMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tabelSpp);

        jLabel6.setFont(new java.awt.Font("Segoe UI", 3, 16)); // NOI18N
        jLabel6.setText("Data Tagihan");

        tabelTagihan.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "Id Tagihan", "NIS", "Nama", "Id SPP", "Status", "File Path"
            }
        ));
        tabelTagihan.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tabelTagihanMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(tabelTagihan);

        jLabel7.setText("Id Tagihan");

        labelIdtagihan.setText("-");

        tomLunas.setText("Lunas");
        tomLunas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tomLunasActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addComponent(jLabel1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel4, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel3, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel5, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addComponent(tomTambah, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tomBatal, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(32, 32, 32)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(teksNominal, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 180, Short.MAX_VALUE)
                                    .addComponent(teksBulan, javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(teksTahun, javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(teksIdspp, javax.swing.GroupLayout.Alignment.LEADING)))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(tomUpdate, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(tomDelete, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGap(18, 18, 18)
                        .addComponent(jScrollPane1))
                    .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel6)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 800, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(tomLunas)
                        .addGroup(layout.createSequentialGroup()
                            .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 62, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addComponent(labelIdtagihan, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2)
                            .addComponent(teksIdspp, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(teksTahun, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel3))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(teksBulan, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel4))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(teksNominal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel5))
                        .addGap(86, 86, 86)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(tomTambah)
                            .addComponent(tomUpdate))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(tomDelete)
                            .addComponent(tomBatal)))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addComponent(jLabel6)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 196, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(labelIdtagihan))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(tomLunas)
                .addContainerGap(75, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void teksIdsppActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_teksIdsppActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_teksIdsppActionPerformed

    private void tabelSppMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tabelSppMouseClicked
        int baris = tabelSpp.getSelectedRow();
        if (baris != -1) {
            teksIdspp.setText(model.getValueAt(baris, 0).toString());
            teksTahun.setText(model.getValueAt(baris, 1).toString());
            teksBulan.setText(model.getValueAt(baris, 2).toString());
            teksNominal.setText(model.getValueAt(baris, 3).toString());
            teksIdspp.setEditable(false);

            // Tandai sedang dalam mode edit
            modeEdit = true;

            // Atur tombol
            setButtonStateTabelKlik();
        }
    }//GEN-LAST:event_tabelSppMouseClicked

    private void tomTambahActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tomTambahActionPerformed
        // TODO add your handling code here:
        try {
            // 1. Tambah ke tabel spp
            String id_spp = teksIdspp.getText();
            String tahun = teksTahun.getText();
            String bulan = teksBulan.getText();
            String nominal = teksNominal.getText();

            Connection conn = koneksi.getKoneksi();

            // INSERT ke spp
            String sqlSpp = "INSERT INTO spp (id_spp, tahun, bulan, nominal) VALUES (?, ?, ?, ?)";
            PreparedStatement pstSpp = conn.prepareStatement(sqlSpp);
            pstSpp.setString(1, id_spp);
            pstSpp.setString(2, tahun);
            pstSpp.setString(3, bulan);
            pstSpp.setString(4, nominal);
            pstSpp.executeUpdate();

            // 2. Ambil semua NIS siswa
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT nis FROM siswa");

            // 3. Tambahkan ke tabel tagihan
            String sqlTagihan = "INSERT INTO tagihan (id_tagihan, status, file_path, id_spp, nis) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement pstTagihan = conn.prepareStatement(sqlTagihan);

            while (rs.next()) {
                String nis = rs.getString("nis");
                String id_tagihan = id_spp + "-" + nis; // Contoh format: 2507-231101

                pstTagihan.setString(1, id_tagihan);
                pstTagihan.setString(2, "Belum");       // status default
                pstTagihan.setString(3, "-");           // file_path default
                pstTagihan.setString(4, id_spp);
                pstTagihan.setString(5, nis);
                pstTagihan.executeUpdate();
            }

            JOptionPane.showMessageDialog(this, "Data berhasil ditambahkan dan tagihan dibuat.");
            clearForm();
            loadTable();
            loadTabelTagihan();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Tambah data gagal: " + e.getMessage());
        }
    }//GEN-LAST:event_tomTambahActionPerformed

    private void tomUpdateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tomUpdateActionPerformed
        // TODO add your handling code here:
        try {
            String sql = "UPDATE spp SET tahun=?, bulan=?, nominal=? WHERE id_spp=?";
            Connection conn = koneksi.getKoneksi();
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.setString(1, teksTahun.getText());
            pst.setString(2, teksBulan.getText());
            pst.setString(3, teksNominal.getText());
            pst.setString(4, teksIdspp.getText());
            pst.executeUpdate();

            JOptionPane.showMessageDialog(this, "Data berhasil diupdate.");
            clearForm();
            loadTable();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Update gagal: " + e.getMessage());
        }
    }//GEN-LAST:event_tomUpdateActionPerformed

    private void tomBatalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tomBatalActionPerformed
        // TODO add your handling code here:
        clearForm();
    }//GEN-LAST:event_tomBatalActionPerformed

    private void tomDeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tomDeleteActionPerformed
        // TODO add your handling code here:
        try {
            String id_spp = teksIdspp.getText();
            Connection conn = koneksi.getKoneksi();

            // 1. Hapus semua tagihan yang berkaitan dengan id_spp
            String sqlTagihan = "DELETE FROM tagihan WHERE id_spp=?";
            PreparedStatement pstTagihan = conn.prepareStatement(sqlTagihan);
            pstTagihan.setString(1, id_spp);
            pstTagihan.executeUpdate();

            // 2. Hapus dari tabel spp
            String sqlSpp = "DELETE FROM spp WHERE id_spp=?";
            PreparedStatement pstSpp = conn.prepareStatement(sqlSpp);
            pstSpp.setString(1, id_spp);
            pstSpp.executeUpdate();

            JOptionPane.showMessageDialog(this, "Data berhasil dihapus beserta tagihan terkait.");
            clearForm();
            loadTable();
            loadTabelTagihan();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Hapus gagal: " + e.getMessage());
        }
    }//GEN-LAST:event_tomDeleteActionPerformed

    private void tomUserActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tomUserActionPerformed
        // TODO add your handling code here:
        new view_data_user().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_tomUserActionPerformed

    private void tomKelasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tomKelasActionPerformed
        // TODO add your handling code here:
        new view_data_kelas().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_tomKelasActionPerformed

    private void tomSiswaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tomSiswaActionPerformed
        // TODO add your handling code here:
        new view_data_siswa().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_tomSiswaActionPerformed

    private void tomSppActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tomSppActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tomSppActionPerformed

    private void tomTagihanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tomTagihanActionPerformed
        // TODO add your handling code here:
        new view_data_tagihan().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_tomTagihanActionPerformed

    private void tomLogoutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tomLogoutActionPerformed
        // TODO add your handling code here:
        new view_login().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_tomLogoutActionPerformed

    private void tabelTagihanMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tabelTagihanMouseClicked
        // TODO add your handling code here:
        int row = tabelTagihan.getSelectedRow();
        if (row != -1) {
            String idTagihan = tabelTagihan.getValueAt(row, 0).toString(); // kolom pertama = id_tagihan
            labelIdtagihan.setText(idTagihan); // tampilkan di label
            tomLunas.setEnabled(true);         // aktifkan tombol lunas
        }
    }//GEN-LAST:event_tabelTagihanMouseClicked

    private void tomLunasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tomLunasActionPerformed
        // TODO add your handling code here:
        try {
            String idTagihan = labelIdtagihan.getText();
            Connection conn = koneksi.getKoneksi();
            String sql = "UPDATE tagihan SET status='LUNAS' WHERE id_tagihan=?";
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.setString(1, idTagihan);
            pst.executeUpdate();

            JOptionPane.showMessageDialog(this, "Status tagihan berhasil diubah menjadi LUNAS.");
            loadTabelTagihan(); // refresh tabel
            labelIdtagihan.setText("");        // reset label
            tomLunas.setEnabled(false);        // nonaktifkan kembali tombol
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Gagal mengubah status tagihan: " + e.getMessage());
        }
    }//GEN-LAST:event_tomLunasActionPerformed

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new view_data_spp().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JLabel labelIdtagihan;
    private javax.swing.JTable tabelSpp;
    private javax.swing.JTable tabelTagihan;
    private javax.swing.JTextField teksBulan;
    private javax.swing.JTextField teksIdspp;
    private javax.swing.JTextField teksNominal;
    private javax.swing.JTextField teksTahun;
    private javax.swing.JButton tomBatal;
    private javax.swing.JButton tomDelete;
    private javax.swing.JButton tomKelas;
    private javax.swing.JButton tomLogout;
    private javax.swing.JButton tomLunas;
    private javax.swing.JButton tomSiswa;
    private javax.swing.JButton tomSpp;
    private javax.swing.JButton tomTagihan;
    private javax.swing.JButton tomTambah;
    private javax.swing.JButton tomUpdate;
    private javax.swing.JButton tomUser;
    // End of variables declaration//GEN-END:variables
}
