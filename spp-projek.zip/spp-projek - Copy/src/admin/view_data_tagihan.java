package admin;

import java.sql.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import database.koneksi;

public class view_data_tagihan extends javax.swing.JFrame {
    
    DefaultTableModel modelTagihan, modelRiwayat;

    public view_data_tagihan() {
        initComponents();
        tomLunas.setEnabled(false);
        tomTagihan.setEnabled(false);
        labelIdtagihan.setText("-");
        labelTotal.setText("-");

        tabelTagihan.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                int row = tabelTagihan.getSelectedRow();
                if (row != -1) {
                    labelIdtagihan.setText(tabelTagihan.getValueAt(row, 0).toString());
                    tomLunas.setEnabled(true);
                }
            }
        });
    }
    
    private void tampilTagihan(String nis) {
        modelTagihan = new DefaultTableModel(new String[]{"Id Tagihan", "NIS", "Nama", "Id SPP", "Nominal", "Status", "File Path"}, 0);
        try {
            Connection conn = koneksi.getKoneksi();
            String sql = "SELECT t.id_tagihan, s.nis, s.nama, t.id_spp, spp.nominal, t.status, t.file_path " +
                         "FROM tagihan t JOIN siswa s ON t.nis = s.nis JOIN spp ON t.id_spp = spp.id_spp " +
                         "WHERE t.nis = ? AND t.status = 'Belum'";
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.setString(1, nis);
            ResultSet rs = pst.executeQuery();

            while (rs.next()) {
                modelTagihan.addRow(new Object[]{
                    rs.getString("id_tagihan"),
                    rs.getString("nis"),
                    rs.getString("nama"),
                    rs.getString("id_spp"),
                    rs.getInt("nominal"),
                    rs.getString("status"),
                    rs.getString("file_path")
                });
            }
            tabelTagihan.setModel(modelTagihan);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Gagal menampilkan tagihan: " + e.getMessage());
        }
    }
    
    private void tampilRiwayat(String nis) {
        modelRiwayat = new DefaultTableModel(new String[]{"Id Tagihan", "NIS", "Nama", "Id SPP", "Nominal", "Status", "File Path"}, 0);
        try {
            Connection conn = koneksi.getKoneksi();
            String sql = "SELECT t.id_tagihan, s.nis, s.nama, t.id_spp, spp.nominal, t.status, t.file_path " +
                         "FROM tagihan t JOIN siswa s ON t.nis = s.nis JOIN spp ON t.id_spp = spp.id_spp " +
                         "WHERE t.nis = ? AND t.status = 'LUNAS'";
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.setString(1, nis);
            ResultSet rs = pst.executeQuery();

            while (rs.next()) {
                modelRiwayat.addRow(new Object[]{
                    rs.getString("id_tagihan"),
                    rs.getString("nis"),
                    rs.getString("nama"),
                    rs.getString("id_spp"),
                    rs.getInt("nominal"),
                    rs.getString("status"),
                    rs.getString("file_path")
                });
            }
            tabelRiwayat.setModel(modelRiwayat);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Gagal menampilkan riwayat: " + e.getMessage());
        }
    }

    private void tampilTotalTagihan(String nis) {
        try {
            Connection conn = koneksi.getKoneksi();
            String sql = "SELECT SUM(spp.nominal) AS total FROM tagihan JOIN spp ON tagihan.id_spp = spp.id_spp WHERE tagihan.nis = ? AND tagihan.status = 'Belum'";
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.setString(1, nis);
            ResultSet rs = pst.executeQuery();
            if (rs.next()) {
                labelTotal.setText("Rp " + rs.getInt("total"));
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Gagal menghitung total tagihan: " + e.getMessage());
        }
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane2 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jPanel2 = new javax.swing.JPanel();
        tomUser = new javax.swing.JButton();
        tomSpp = new javax.swing.JButton();
        tomTagihan = new javax.swing.JButton();
        tomSiswa = new javax.swing.JButton();
        tomKelas = new javax.swing.JButton();
        tomLogout = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        teksNIS = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabelTagihan = new javax.swing.JTable();
        tomCari = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        tomLunas = new javax.swing.JButton();
        labelIdtagihan = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        labelTotal = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        tabelRiwayat = new javax.swing.JTable();

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane2.setViewportView(jTable1);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel2.setBackground(new java.awt.Color(51, 102, 255));

        tomUser.setText("Data User");
        tomUser.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tomUserActionPerformed(evt);
            }
        });

        tomSpp.setText("Data  SPP");
        tomSpp.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tomSppActionPerformed(evt);
            }
        });

        tomTagihan.setText("Data Tagihan");
        tomTagihan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tomTagihanActionPerformed(evt);
            }
        });

        tomSiswa.setText("Data Siswa");
        tomSiswa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tomSiswaActionPerformed(evt);
            }
        });

        tomKelas.setText("Data Kelas");
        tomKelas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tomKelasActionPerformed(evt);
            }
        });

        tomLogout.setText("Logout");
        tomLogout.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tomLogoutActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(tomUser, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(tomKelas, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(tomSiswa, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(tomSpp, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(tomTagihan, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(tomLogout, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(tomUser)
                    .addComponent(tomSpp)
                    .addComponent(tomTagihan)
                    .addComponent(tomSiswa)
                    .addComponent(tomKelas)
                    .addComponent(tomLogout))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jLabel1.setFont(new java.awt.Font("Segoe UI", 3, 16)); // NOI18N
        jLabel1.setText("Data Tagihan");

        jLabel2.setText("NIS");

        tabelTagihan.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "Id Tagihan", "NIS", "Nama", "ID SPP", "Status", "File Path"
            }
        ));
        tabelTagihan.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tabelTagihanMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tabelTagihan);

        tomCari.setText("Cari");
        tomCari.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tomCariActionPerformed(evt);
            }
        });

        jLabel7.setText("ID Tagihan");

        tomLunas.setText("Lunas");
        tomLunas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tomLunasActionPerformed(evt);
            }
        });

        labelIdtagihan.setText("-");

        jLabel9.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel9.setText("Total");

        labelTotal.setText("-");

        jLabel3.setFont(new java.awt.Font("Segoe UI", 3, 16)); // NOI18N
        jLabel3.setText("Riwayat Tagihan");

        tabelRiwayat.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "Id Tagihan", "NIS", "Nama", "ID SPP", "Status", "File Path"
            }
        ));
        jScrollPane3.setViewportView(tabelRiwayat);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(jLabel1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jLabel2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addComponent(teksNIS, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(tomCari, javax.swing.GroupLayout.Alignment.TRAILING))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(labelIdtagihan, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addComponent(tomLunas, javax.swing.GroupLayout.Alignment.TRAILING))
                        .addGap(18, 18, 18)
                        .addComponent(jScrollPane1))
                    .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(246, 246, 246)
                        .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(labelTotal, javax.swing.GroupLayout.PREFERRED_SIZE, 59, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel3))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 787, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(teksNIS, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(tomCari)
                        .addGap(28, 28, 28)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel7)
                            .addComponent(labelIdtagihan))
                        .addGap(8, 8, 8)
                        .addComponent(tomLunas))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 227, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel9)
                    .addComponent(labelTotal))
                .addGap(34, 34, 34)
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 227, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(26, 26, 26))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void tabelTagihanMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tabelTagihanMouseClicked
        
    }//GEN-LAST:event_tabelTagihanMouseClicked

    private void tomUserActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tomUserActionPerformed
        // TODO add your handling code here:
        new view_data_user().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_tomUserActionPerformed

    private void tomKelasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tomKelasActionPerformed
        // TODO add your handling code here:
        new view_data_kelas().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_tomKelasActionPerformed

    private void tomSiswaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tomSiswaActionPerformed
        // TODO add your handling code here:
        new view_data_siswa().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_tomSiswaActionPerformed

    private void tomSppActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tomSppActionPerformed
        // TODO add your handling code here:
        new view_data_spp().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_tomSppActionPerformed

    private void tomTagihanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tomTagihanActionPerformed
        // TODO add your handling code here:
        new view_data_tagihan().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_tomTagihanActionPerformed

    private void tomLogoutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tomLogoutActionPerformed
        // TODO add your handling code here:
        new view_login().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_tomLogoutActionPerformed

    private void tomCariActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tomCariActionPerformed
        // TODO add your handling code here:
        String nis = teksNIS.getText();
        if (nis.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Masukkan NIS terlebih dahulu!");
            return;
        }
        tampilTagihan(nis);
        tampilRiwayat(nis);
        tampilTotalTagihan(nis);
    }//GEN-LAST:event_tomCariActionPerformed

    private void tomLunasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tomLunasActionPerformed
        // TODO add your handling code here:
        String idTagihan = labelIdtagihan.getText();
        if (idTagihan.equals("-")) {
            JOptionPane.showMessageDialog(this, "Pilih data terlebih dahulu!");
            return;
        }
        try {
            Connection conn = koneksi.getKoneksi();
            String sql = "UPDATE tagihan SET status='LUNAS' WHERE id_tagihan=?";
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.setString(1, idTagihan);
            pst.executeUpdate();
            JOptionPane.showMessageDialog(this, "Status berhasil diubah menjadi LUNAS");
            tomCariActionPerformed(null);
            labelIdtagihan.setText("-");
            tomLunas.setEnabled(false);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Gagal update status: " + e.getMessage());
        }
    }//GEN-LAST:event_tomLunasActionPerformed

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new view_data_tagihan().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTable jTable1;
    private javax.swing.JLabel labelIdtagihan;
    private javax.swing.JLabel labelTotal;
    private javax.swing.JTable tabelRiwayat;
    private javax.swing.JTable tabelTagihan;
    private javax.swing.JTextField teksNIS;
    private javax.swing.JButton tomCari;
    private javax.swing.JButton tomKelas;
    private javax.swing.JButton tomLogout;
    private javax.swing.JButton tomLunas;
    private javax.swing.JButton tomSiswa;
    private javax.swing.JButton tomSpp;
    private javax.swing.JButton tomTagihan;
    private javax.swing.JButton tomUser;
    // End of variables declaration//GEN-END:variables
}
