package admin;

import java.sql.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import database.koneksi;

public class view_data_siswa extends javax.swing.JFrame {
    
    DefaultTableModel model;

    public view_data_siswa() {
        initComponents();
        loadKelas();       
        loadUser();        
        loadTabel();       
        setAwal();
    }
    
    private void setAwal() {
        tomTambah.setEnabled(true);
        tomBatal.setEnabled(true);
        tomUpdate.setEnabled(false);
        tomDelete.setEnabled(false);
        tomSiswa.setEnabled(false); // karena sedang di halaman Data Siswa
        tomSiswa.setEnabled(false);

        tomUser.setEnabled(true);
        tomKelas.setEnabled(true);
        tomSpp.setEnabled(true);
        tomTagihan.setEnabled(true);
        tomLogout.setEnabled(true);
    }
    
    private void loadKelas() {
        try {
            Connection conn = koneksi.getKoneksi();
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT nama_kelas FROM kelas");

            comboNamakelas.removeAllItems();
            while (rs.next()) {
                comboNamakelas.addItem(rs.getString("nama_kelas"));
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Gagal memuat data kelas: " + e.getMessage());
        }
    }
    
    private void loadUser() {
        try {
            Connection conn = koneksi.getKoneksi();
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT id_user FROM user WHERE role='siswa'");

            comboIduser.removeAllItems();
            while (rs.next()) {
                comboIduser.addItem(rs.getString("id_user"));
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Gagal memuat data user: " + e.getMessage());
        }
    }

    private void loadTabel() {
        model = new DefaultTableModel();
        model.addColumn("NIS");
        model.addColumn("Nama");
        model.addColumn("Jenis Kelamin");
        model.addColumn("Nama Kelas");
        model.addColumn("Id User");

        try {
            Connection conn = koneksi.getKoneksi();
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(
                "SELECT s.nis, s.nama, s.jenis_kelamin, k.nama_kelas, s.id_user " +
                "FROM siswa s JOIN kelas k ON s.id_kelas = k.id_kelas"
            );

            while (rs.next()) {
                model.addRow(new Object[]{
                    rs.getString("nis"),
                    rs.getString("nama"),
                    rs.getString("jenis_kelamin"),
                    rs.getString("nama_kelas"),
                    rs.getString("id_user")
                });
            }

            tabelSiswa.setModel(model);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Gagal memuat data siswa: " + e.getMessage());
        }
    }

    private void loadComboBoxes() {
        try {
            Connection conn = koneksi.getKoneksi();
            Statement stmt = conn.createStatement();

            ResultSet kelas = stmt.executeQuery("SELECT nama_kelas FROM kelas");
            while (kelas.next()) {
                comboNamakelas.addItem(kelas.getString("nama_kelas"));
            }

            ResultSet users = stmt.executeQuery("SELECT id_user FROM user WHERE role='siswa'");
            while (users.next()) {
                comboIduser.addItem(users.getString("id_user"));
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Gagal memuat combo box: " + e.getMessage());
        }
    }

    private void clearForm() {
        teksNIS.setText("");
        teksNama.setText("");
        teksJeniskelamin.setText("");
        comboNamakelas.setSelectedIndex(0);
        comboIduser.setSelectedIndex(0);
        setAwal();
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        tomUser = new javax.swing.JButton();
        tomSpp = new javax.swing.JButton();
        tomTagihan = new javax.swing.JButton();
        tomSiswa = new javax.swing.JButton();
        tomKelas = new javax.swing.JButton();
        tomLogout = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        teksNama = new javax.swing.JTextField();
        teksJeniskelamin = new javax.swing.JTextField();
        teksNIS = new javax.swing.JTextField();
        tomTambah = new javax.swing.JButton();
        tomUpdate = new javax.swing.JButton();
        tomDelete = new javax.swing.JButton();
        tomBatal = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabelSiswa = new javax.swing.JTable();
        comboNamakelas = new javax.swing.JComboBox<>();
        comboIduser = new javax.swing.JComboBox<>();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel2.setBackground(new java.awt.Color(51, 102, 255));

        tomUser.setText("Data User");
        tomUser.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tomUserActionPerformed(evt);
            }
        });

        tomSpp.setText("Data  SPP");
        tomSpp.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tomSppActionPerformed(evt);
            }
        });

        tomTagihan.setText("Data Tagihan");
        tomTagihan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tomTagihanActionPerformed(evt);
            }
        });

        tomSiswa.setText("Data Siswa");
        tomSiswa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tomSiswaActionPerformed(evt);
            }
        });

        tomKelas.setText("Data Kelas");
        tomKelas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tomKelasActionPerformed(evt);
            }
        });

        tomLogout.setText("Logout");
        tomLogout.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tomLogoutActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(tomUser, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(tomKelas, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(tomSiswa, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(tomSpp, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(tomTagihan, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(tomLogout, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(tomUser)
                    .addComponent(tomSpp)
                    .addComponent(tomTagihan)
                    .addComponent(tomSiswa)
                    .addComponent(tomKelas)
                    .addComponent(tomLogout))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jLabel1.setFont(new java.awt.Font("Segoe UI", 3, 16)); // NOI18N
        jLabel1.setText("Data Siswa");

        jLabel2.setText("NIS");

        jLabel3.setText("Nama");

        jLabel4.setText("Jenis Kelamin");

        jLabel5.setText("Nama Kelas");

        jLabel6.setText("Id User");

        teksNIS.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                teksNISActionPerformed(evt);
            }
        });

        tomTambah.setText("Tambah");
        tomTambah.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tomTambahActionPerformed(evt);
            }
        });

        tomUpdate.setText("Update");
        tomUpdate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tomUpdateActionPerformed(evt);
            }
        });

        tomDelete.setText("Delete");
        tomDelete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tomDeleteActionPerformed(evt);
            }
        });

        tomBatal.setText("Batal");
        tomBatal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tomBatalActionPerformed(evt);
            }
        });

        tabelSiswa.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "NIS", "Nama", "Jenis Kelamin", "Nama Kelas", "Id User"
            }
        ));
        tabelSiswa.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tabelSiswaMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tabelSiswa);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addComponent(jLabel1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel4, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel3, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel5, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel6, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addComponent(tomTambah, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tomBatal, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(tomUpdate, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(tomDelete, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(32, 32, 32)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(teksJeniskelamin, javax.swing.GroupLayout.DEFAULT_SIZE, 180, Short.MAX_VALUE)
                                    .addComponent(teksNama)
                                    .addComponent(teksNIS)
                                    .addComponent(comboNamakelas, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(comboIduser, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                        .addGap(18, 18, 18)
                        .addComponent(jScrollPane1))
                    .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2)
                            .addComponent(teksNIS, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(teksNama, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel3))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel4)
                            .addComponent(teksJeniskelamin, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel5)
                            .addComponent(comboNamakelas, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(17, 17, 17)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel6)
                            .addComponent(comboIduser, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(47, 47, 47)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(tomTambah)
                            .addComponent(tomUpdate))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(tomDelete)
                            .addComponent(tomBatal)))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(55, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void teksNISActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_teksNISActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_teksNISActionPerformed

    private void tabelSiswaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tabelSiswaMouseClicked
        int baris = tabelSiswa.getSelectedRow();
        if (baris != -1) {
            teksNIS.setText(model.getValueAt(baris, 0).toString());
            teksNama.setText(model.getValueAt(baris, 1).toString());
            teksJeniskelamin.setText(model.getValueAt(baris, 2).toString());
            comboNamakelas.setSelectedItem(model.getValueAt(baris, 3).toString());
            comboIduser.setSelectedItem(model.getValueAt(baris, 4).toString());

            teksNIS.setEditable(false);
            tomTambah.setEnabled(false);
            tomUpdate.setEnabled(true);
            tomDelete.setEnabled(true);
            tomBatal.setEnabled(true);
        }
    }//GEN-LAST:event_tabelSiswaMouseClicked

    private void tomTambahActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tomTambahActionPerformed
        // TODO add your handling code here:
        try {
            Connection conn = koneksi.getKoneksi();
            PreparedStatement pst = conn.prepareStatement("INSERT INTO siswa (nis, nama, jenis_kelamin, id_kelas, id_user) VALUES (?, ?, ?, (SELECT id_kelas FROM kelas WHERE nama_kelas=?), ?)");
            pst.setString(1, teksNIS.getText());
            pst.setString(2, teksNama.getText());
            pst.setString(3, teksJeniskelamin.getText());
            pst.setString(4, comboNamakelas.getSelectedItem().toString());
            pst.setString(5, comboIduser.getSelectedItem().toString());
            pst.executeUpdate();
            JOptionPane.showMessageDialog(this, "Data berhasil ditambahkan.");
            clearForm();
            loadTabel();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Tambah data gagal: " + e.getMessage());
        }
    }//GEN-LAST:event_tomTambahActionPerformed

    private void tomUpdateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tomUpdateActionPerformed
        // TODO add your handling code here:
        try {
            Connection conn = koneksi.getKoneksi();
            PreparedStatement pst = conn.prepareStatement("UPDATE siswa SET nama=?, jenis_kelamin=?, id_kelas=(SELECT id_kelas FROM kelas WHERE nama_kelas=?), id_user=? WHERE nis=?");
            pst.setString(1, teksNama.getText());
            pst.setString(2, teksJeniskelamin.getText());
            pst.setString(3, comboNamakelas.getSelectedItem().toString());
            pst.setString(4, comboIduser.getSelectedItem().toString());
            pst.setString(5, teksNIS.getText());
            pst.executeUpdate();
            JOptionPane.showMessageDialog(this, "Data berhasil diupdate.");
            clearForm();
            loadTabel();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Update gagal: " + e.getMessage());
        }
    }//GEN-LAST:event_tomUpdateActionPerformed

    private void tomBatalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tomBatalActionPerformed
        // TODO add your handling code here:
        clearForm();
    }//GEN-LAST:event_tomBatalActionPerformed

    private void tomDeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tomDeleteActionPerformed
        // TODO add your handling code here:
        try {
            Connection conn = koneksi.getKoneksi();
            PreparedStatement pst = conn.prepareStatement("DELETE FROM siswa WHERE nis=?");
            pst.setString(1, teksNIS.getText());
            pst.executeUpdate();
            JOptionPane.showMessageDialog(this, "Data berhasil dihapus.");
            clearForm();
            loadTabel();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Hapus gagal: " + e.getMessage());
        }
    }//GEN-LAST:event_tomDeleteActionPerformed

    private void tomUserActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tomUserActionPerformed
        // TODO add your handling code here:
        new view_data_user().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_tomUserActionPerformed

    private void tomKelasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tomKelasActionPerformed
        // TODO add your handling code here:
        new view_data_kelas().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_tomKelasActionPerformed

    private void tomSiswaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tomSiswaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tomSiswaActionPerformed

    private void tomSppActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tomSppActionPerformed
        // TODO add your handling code here:
        new view_data_spp().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_tomSppActionPerformed

    private void tomTagihanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tomTagihanActionPerformed
        // TODO add your handling code here:
        new view_data_tagihan().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_tomTagihanActionPerformed

    private void tomLogoutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tomLogoutActionPerformed
        // TODO add your handling code here:
        new view_login().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_tomLogoutActionPerformed

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new view_data_siswa().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> comboIduser;
    private javax.swing.JComboBox<String> comboNamakelas;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tabelSiswa;
    private javax.swing.JTextField teksJeniskelamin;
    private javax.swing.JTextField teksNIS;
    private javax.swing.JTextField teksNama;
    private javax.swing.JButton tomBatal;
    private javax.swing.JButton tomDelete;
    private javax.swing.JButton tomKelas;
    private javax.swing.JButton tomLogout;
    private javax.swing.JButton tomSiswa;
    private javax.swing.JButton tomSpp;
    private javax.swing.JButton tomTagihan;
    private javax.swing.JButton tomTambah;
    private javax.swing.JButton tomUpdate;
    private javax.swing.JButton tomUser;
    // End of variables declaration//GEN-END:variables
}
