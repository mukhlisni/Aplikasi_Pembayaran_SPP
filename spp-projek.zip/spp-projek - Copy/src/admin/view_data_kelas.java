package admin;

import java.sql.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import database.koneksi;

public class view_data_kelas extends javax.swing.JFrame {
    
    DefaultTableModel model;
    private boolean modeEdit = false;

    public view_data_kelas() {
        initComponents();
        tomKelas.setEnabled(false); // dinonaktifkan karena sudah di halaman ini
        loadTable();
        setButtonStateAwal();
        addTextFieldListeners();
        teksIdkelas.setEditable(true);
    }
    
    private void loadTable() {
        model = new DefaultTableModel();
        model.addColumn("Id Kelas");
        model.addColumn("Kelas");
        model.addColumn("Jurusan");
        model.addColumn("Nama Kelas");

        try {
            String sql = "SELECT * FROM kelas";
            Connection conn = koneksi.getKoneksi();
            Statement stmt = conn.createStatement();
            ResultSet res = stmt.executeQuery(sql);

            while (res.next()) {
                model.addRow(new Object[]{
                    res.getString("id_kelas"),
                    res.getString("kelas"),
                    res.getString("jurusan"),
                    res.getString("nama_kelas"),
                });
            }

            tabelKelas.setModel(model);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Gagal memuat data: " + e.getMessage());
        }
    }

    private void addTextFieldListeners() {
        java.awt.event.KeyAdapter listener = new java.awt.event.KeyAdapter() {
            @Override
            public void keyReleased(java.awt.event.KeyEvent evt) {
                if (!modeEdit) {
                    setButtonStateFormAktif();
                }
            }
        };

        teksIdkelas.addKeyListener(listener);
        teksKelas.addKeyListener(listener);
        teksJurusan.addKeyListener(listener);
        teksNamakelas.addKeyListener(listener);
    }

    private void setButtonStateAwal() {
        tomTambah.setEnabled(false);
        tomUpdate.setEnabled(false);
        tomDelete.setEnabled(false);
        tomBatal.setEnabled(false);
    }

    private void setButtonStateFormAktif() {
        tomTambah.setEnabled(true);
        tomUpdate.setEnabled(false);
        tomDelete.setEnabled(false);
        tomBatal.setEnabled(true);
    }

    private void setButtonStateTabelKlik() {
        tomTambah.setEnabled(false);
        tomUpdate.setEnabled(true);
        tomDelete.setEnabled(true);
        tomBatal.setEnabled(true);
    }

    private void clearForm() {
        teksIdkelas.setText("");
        teksKelas.setText("");
        teksJurusan.setText("");
        teksNamakelas.setText("");
        teksIdkelas.setEditable(true);
        setButtonStateAwal();
        modeEdit = false;
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        tomUser = new javax.swing.JButton();
        tomSpp = new javax.swing.JButton();
        tomTagihan = new javax.swing.JButton();
        tomSiswa = new javax.swing.JButton();
        tomKelas = new javax.swing.JButton();
        tomLogout = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        teksKelas = new javax.swing.JTextField();
        teksJurusan = new javax.swing.JTextField();
        teksNamakelas = new javax.swing.JTextField();
        teksIdkelas = new javax.swing.JTextField();
        tomTambah = new javax.swing.JButton();
        tomUpdate = new javax.swing.JButton();
        tomDelete = new javax.swing.JButton();
        tomBatal = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabelKelas = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel2.setBackground(new java.awt.Color(51, 102, 255));

        tomUser.setText("Data User");
        tomUser.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tomUserActionPerformed(evt);
            }
        });

        tomSpp.setText("Data  SPP");
        tomSpp.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tomSppActionPerformed(evt);
            }
        });

        tomTagihan.setText("Data Tagihan");
        tomTagihan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tomTagihanActionPerformed(evt);
            }
        });

        tomSiswa.setText("Data Siswa");
        tomSiswa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tomSiswaActionPerformed(evt);
            }
        });

        tomKelas.setText("Data Kelas");
        tomKelas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tomKelasActionPerformed(evt);
            }
        });

        tomLogout.setText("Logout");
        tomLogout.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tomLogoutActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(tomUser, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(tomKelas, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(tomSiswa, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(tomSpp, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(tomTagihan, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(tomLogout, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(tomUser)
                    .addComponent(tomSpp)
                    .addComponent(tomTagihan)
                    .addComponent(tomSiswa)
                    .addComponent(tomKelas)
                    .addComponent(tomLogout))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jLabel1.setFont(new java.awt.Font("Segoe UI", 3, 16)); // NOI18N
        jLabel1.setText("Data Kelas");

        jLabel2.setText("Id Kelas");

        jLabel3.setText("Kelas");

        jLabel4.setText("Jurusan");

        jLabel5.setText("Nama Kelas");

        teksIdkelas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                teksIdkelasActionPerformed(evt);
            }
        });

        tomTambah.setText("Tambah");
        tomTambah.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tomTambahActionPerformed(evt);
            }
        });

        tomUpdate.setText("Update");
        tomUpdate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tomUpdateActionPerformed(evt);
            }
        });

        tomDelete.setText("Delete");
        tomDelete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tomDeleteActionPerformed(evt);
            }
        });

        tomBatal.setText("Batal");
        tomBatal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tomBatalActionPerformed(evt);
            }
        });

        tabelKelas.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Id Kelas", "Kelas", "Jurusan", "Nama Kelas"
            }
        ));
        tabelKelas.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tabelKelasMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tabelKelas);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addComponent(jLabel1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel4, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel3, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel5, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addComponent(tomTambah, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tomBatal, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(32, 32, 32)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(teksNamakelas, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 180, Short.MAX_VALUE)
                                    .addComponent(teksJurusan, javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(teksKelas, javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(teksIdkelas, javax.swing.GroupLayout.Alignment.LEADING)))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(tomUpdate, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(tomDelete, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGap(18, 18, 18)
                        .addComponent(jScrollPane1))
                    .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2)
                            .addComponent(teksIdkelas, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(teksKelas, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel3))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(teksJurusan, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel4))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(teksNamakelas, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel5))
                        .addGap(86, 86, 86)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(tomTambah)
                            .addComponent(tomUpdate))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(tomDelete)
                            .addComponent(tomBatal)))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(55, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void teksIdkelasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_teksIdkelasActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_teksIdkelasActionPerformed

    private void tabelKelasMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tabelKelasMouseClicked
        int baris = tabelKelas.getSelectedRow();
        if (baris != -1) {
            teksIdkelas.setText(model.getValueAt(baris, 0).toString());
            teksKelas.setText(model.getValueAt(baris, 1).toString());
            teksJurusan.setText(model.getValueAt(baris, 2).toString());
            teksNamakelas.setText(model.getValueAt(baris, 3).toString());
            teksIdkelas.setEditable(false);

            // Tandai sedang dalam mode edit
            modeEdit = true;

            // Atur tombol
            setButtonStateTabelKlik();
        }
    }//GEN-LAST:event_tabelKelasMouseClicked

    private void tomTambahActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tomTambahActionPerformed
        // TODO add your handling code here:
        try {
            String sql = "INSERT INTO kelas (id_kelas, kelas, jurusan, nama_kelas) VALUES (?, ?, ?, ?)";
            Connection conn = koneksi.getKoneksi();
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.setString(1, teksIdkelas.getText());
            pst.setString(2, teksKelas.getText());
            pst.setString(3, teksJurusan.getText());
            pst.setString(4, teksNamakelas.getText());
            pst.executeUpdate();

            JOptionPane.showMessageDialog(this, "Data berhasil ditambahkan.");
            clearForm();
            loadTable();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Tambah data gagal: " + e.getMessage());
        }
    }//GEN-LAST:event_tomTambahActionPerformed

    private void tomUpdateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tomUpdateActionPerformed
        // TODO add your handling code here:
        try {
            String sql = "UPDATE kelas SET kelas=?, jurusan=?, nama_kelas=? WHERE id_kelas=?";
            Connection conn = koneksi.getKoneksi();
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.setString(1, teksKelas.getText());
            pst.setString(2, teksJurusan.getText());
            pst.setString(3, teksNamakelas.getText());
            pst.setString(4, teksIdkelas.getText());
            pst.executeUpdate();

            JOptionPane.showMessageDialog(this, "Data berhasil diupdate.");
            clearForm();
            loadTable();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Update gagal: " + e.getMessage());
        }
    }//GEN-LAST:event_tomUpdateActionPerformed

    private void tomBatalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tomBatalActionPerformed
        // TODO add your handling code here:
        clearForm();
    }//GEN-LAST:event_tomBatalActionPerformed

    private void tomDeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tomDeleteActionPerformed
        // TODO add your handling code here:
        try {
            String sql = "DELETE FROM kelas WHERE id_kelas=?";
            Connection conn = koneksi.getKoneksi();
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.setString(1, teksIdkelas.getText());
            pst.executeUpdate();

            JOptionPane.showMessageDialog(this, "Data berhasil dihapus.");
            clearForm();
            loadTable();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Hapus gagal: " + e.getMessage());
        }
    }//GEN-LAST:event_tomDeleteActionPerformed

    private void tomUserActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tomUserActionPerformed
        // TODO add your handling code here:
        new view_data_user().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_tomUserActionPerformed

    private void tomKelasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tomKelasActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tomKelasActionPerformed

    private void tomSiswaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tomSiswaActionPerformed
        // TODO add your handling code here:
        new view_data_siswa().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_tomSiswaActionPerformed

    private void tomSppActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tomSppActionPerformed
        // TODO add your handling code here:
        new view_data_spp().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_tomSppActionPerformed

    private void tomTagihanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tomTagihanActionPerformed
        // TODO add your handling code here:
        new view_data_tagihan().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_tomTagihanActionPerformed

    private void tomLogoutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tomLogoutActionPerformed
        // TODO add your handling code here:
        new view_login().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_tomLogoutActionPerformed

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new view_data_kelas().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tabelKelas;
    private javax.swing.JTextField teksIdkelas;
    private javax.swing.JTextField teksJurusan;
    private javax.swing.JTextField teksKelas;
    private javax.swing.JTextField teksNamakelas;
    private javax.swing.JButton tomBatal;
    private javax.swing.JButton tomDelete;
    private javax.swing.JButton tomKelas;
    private javax.swing.JButton tomLogout;
    private javax.swing.JButton tomSiswa;
    private javax.swing.JButton tomSpp;
    private javax.swing.JButton tomTagihan;
    private javax.swing.JButton tomTambah;
    private javax.swing.JButton tomUpdate;
    private javax.swing.JButton tomUser;
    // End of variables declaration//GEN-END:variables
}
